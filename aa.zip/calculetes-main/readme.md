# Calculetes

Mathematics for JavaScript.

Currently supports: Derivates and Integrals.

Read the [documentation](./packages/calculetes/).

## Project Structure

This is a monorepo, currently for a page that serves as example,
and the library itself.

```tree
├── packages
│   ├── calculetes
│   └── page
└── package.json
```

## License

MIT License
