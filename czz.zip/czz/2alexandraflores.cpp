#include <iostream>

using namespace std;

double calcularDeterminante(const double *matriz, int dimension)
{
  // Caso base: matriz 1x1
  if (dimension == 1)
  {
    return matriz[0];
  }

  // Encontrar la fila con más ceros para optimizar el cálculo
  int mejorFila = 0, maximoCeros = -1;
  for (int i = 0; i < dimension; ++i)
  {
    int contadorCeros = 0;
    for (int j = 0; j < dimension; ++j)
    {
      if (matriz[i * dimension + j] == 0.0)
        ++contadorCeros;
    }
    // Si la fila tiene solo ceros, el determinante es cero
    if (contadorCeros == dimension)
    {
      return 0.0;
    }
    if (contadorCeros > maximoCeros)
    {
      maximoCeros = contadorCeros;
      mejorFila = i;
    }
  }

  // Inicializar el determinante y la submatriz
  double determinante = 0.0;
  double *submatriz = new double[(dimension - 1) * (dimension - 1)];

  // Calcular la expansión por cofactores a lo largo de la fila elegida
  for (int columna = 0; columna < dimension; ++columna)
  {
    double valor = matriz[mejorFila * dimension + columna];
    // Saltar elementos cero (no contribuyen al determinante)
    if (valor == 0.0)
      continue;

    // Construir submatriz eliminando la fila y columna actuales
    for (int fila = 0, subfila = 0; fila < dimension; ++fila)
    {
      if (fila == mejorFila)
        continue;
      for (int col = 0, subcolumna = 0; col < dimension; ++col)
      {
        if (col == columna)
          continue;
        submatriz[subfila * (dimension - 1) + subcolumna] = matriz[fila * dimension + col];
        ++subcolumna;
      }
      ++subfila;
    }

    // Calcular el signo del cofactor: (-1)^(fila+columna)
    double signo = ((mejorFila + columna) % 2 == 0) ? 1.0 : -1.0;
    // Sumar la contribución de este cofactor al determinante
    determinante += signo * valor * calcularDeterminante(submatriz, dimension - 1);
  }

  // Liberar memoria de la submatriz
  delete[] submatriz;
  return determinante;
}

double valorAbsoluto(double numero)
{
  return numero * ((numero > 0) - (numero < 0));
}

int redondear(double numero)
{
  if (numero >= 0.0)
    return static_cast<int>(numero + 0.5);
  else
    return static_cast<int>(numero - 0.5);
}

int main()
{
  // Solicitar el tamaño de la matriz
  int dimension;
  cout << "Ingrese el tamaño de la matriz (máximo 10): ";
  if (!(cin >> dimension) || dimension < 1 || dimension > 10)
  {
    cout << "Tamaño inválido. Debe ser entre 1 y 10.\n";
    return 1;
  }

  // Crear matriz y solicitar los elementos
  double *matriz = new double[dimension * dimension];
  cout << "Ingrese los " << (dimension * dimension) << " elementos de la matriz:\n";
  for (int i = 0; i < dimension * dimension; ++i)
  {
    cin >> matriz[i];
  }

  // Calcular el determinante
  double determinante = calcularDeterminante(matriz, dimension);
  // Verificar si el resultado es prácticamente un entero
  double diferencia = valorAbsoluto(determinante - redondear(determinante));
  if (diferencia < 1e-9)
  {
    cout << "Determinante = " << redondear(determinante) << "\n";
  }
  else
  {
    cout << "Determinante = " << determinante << "\n";
  }

  // Liberar memoria
  delete[] matriz;
  return 0;
}
