#include <iostream>

using namespace std;

void cambiarValores(int &valorA, int &valorB)
{
  int auxiliar = valorA;
  valorA = valorB;
  valorB = auxiliar;
}

void crearArreglo(int *&arreglo, int longitud)
{
  arreglo = new int[longitud];
}

void leerValores(int *arreglo, int longitud, istream &entrada)
{
  for (int indice = 0; indice < longitud; ++indice)
  {
    entrada >> arreglo[indice];
  }
}

void mostrarArreglo(int *arreglo, int longitud, ostream &salida)
{
  for (int indice = 0; indice < longitud; ++indice)
  {
    salida << arreglo[indice] << " ";
  }
  salida << endl;
}

void eliminarArreglo(int *&arreglo)
{
  delete[] arreglo;
  arreglo = nullptr;
}

void intercambiarPunteros(int *&arregloA, int *&arregloB)
{
  int *auxiliar = arregloA;
  arregloA = arregloB;
  arregloB = auxiliar;
}

template <bool OrdenAscendente = true>
void ordenarBurbujaRecursivo(int *arreglo, int cantidad)
{
  if (cantidad <= 1)
    return;

  for (int posicion = 1; posicion < cantidad; ++posicion)
  {
    if (OrdenAscendente ? (arreglo[posicion] > arreglo[0]) : (arreglo[posicion] < arreglo[0]))
    {
      cambiarValores(arreglo[0], arreglo[posicion]);
    }
  }

  ordenarBurbujaRecursivo<OrdenAscendente>(arreglo + 1, cantidad - 1);
}

int main()
{
  int *arregloUno = nullptr, tamano = 10;
  int *arregloDos = nullptr;

  // Crear, leer y ordenar el primer arreglo (ascendente)
  crearArreglo(arregloUno, tamano);
  leerValores(arregloUno, tamano, cin);
  ordenarBurbujaRecursivo<>(arregloUno, tamano); // Orden ascendente
  mostrarArreglo(arregloUno, tamano, cout);

  // Crear, leer y ordenar el segundo arreglo (descendente)
  crearArreglo(arregloDos, tamano);
  leerValores(arregloDos, tamano, cin);
  ordenarBurbujaRecursivo<false>(arregloDos, tamano); // Orden descendente
  mostrarArreglo(arregloDos, tamano, cout);

  // Intercambiar los punteros de los arreglos
  intercambiarPunteros(arregloUno, arregloDos);

  // Liberar la memoria de ambos arreglos
  eliminarArreglo(arregloUno);
  eliminarArreglo(arregloDos);

  return 0;
}