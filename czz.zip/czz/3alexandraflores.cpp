#include <iostream>
using namespace std;

// Definición de la dimensión máxima permitida para el laberinto
const int DIMENSION_MAXIMA = 100;

void explorarZona(int **laberinto, bool **explorado, int alto, int ancho, int fila, int columna)
{
  // Verificar límites del laberinto, si ya fue explorado o si es un obstáculo
  if (fila < 0 || fila >= alto || columna < 0 || columna >= ancho || explorado[fila][columna] || laberinto[fila][columna] == 1)
  {
    return;
  }

  // Marcar como explorada la celda actual
  explorado[fila][columna] = true;

  // Explorar recursivamente las cuatro direcciones (norte, sur, este, oeste)
  explorarZona(laberinto, explorado, alto, ancho, fila - 1, columna);
  explorarZona(laberinto, explorado, alto, ancho, fila + 1, columna);
  explorarZona(laberinto, explorado, alto, ancho, fila, columna - 1);
  explorarZona(laberinto, explorado, alto, ancho, fila, columna + 1);
}

int main()
{
  // Declaración de variables para dimensiones del laberinto
  int alto, ancho;
  cout << "Ingrese el número de filas y columnas del laberinto: ";
  cin >> alto >> ancho;

  // Validar que las dimensiones no excedan el límite
  if (alto > DIMENSION_MAXIMA || ancho > DIMENSION_MAXIMA)
  {
    cout << "Las dimensiones exceden el tamaño máximo permitido de " << DIMENSION_MAXIMA << "x" << DIMENSION_MAXIMA << endl;
    return 1;
  }

  // Asignación dinámica de memoria para la matriz del laberinto
  int **laberinto = new int *[alto];
  for (int i = 0; i < alto; ++i)
  {
    laberinto[i] = new int[ancho];
  }

  // Matriz para realizar seguimiento de celdas exploradas
  bool **explorado = new bool *[alto];
  for (int i = 0; i < alto; ++i)
  {
    explorado[i] = new bool[ancho];
    // Inicializar todas las celdas como no exploradas
    for (int j = 0; j < ancho; ++j)
      explorado[i][j] = false;
  }

  // Solicitar al usuario ingresar la estructura del laberinto
  cout << "Ingrese los valores del laberinto (0 = camino transitable, 1 = pared/obstáculo):\n";
  for (int i = 0; i < alto; ++i)
  {
    for (int j = 0; j < ancho; ++j)
    {
      cin >> laberinto[i][j];
    }
  }

  // Contador de zonas transitables independientes
  int zonasConectadas = 0;

  // Recorrer el laberinto para identificar zonas conectadas
  for (int i = 0; i < alto; ++i)
  {
    for (int j = 0; j < ancho; ++j)
    {
      // Si encontramos un camino no explorado, exploramos toda la zona conectada
      if (laberinto[i][j] == 0 && !explorado[i][j])
      {
        explorarZona(laberinto, explorado, alto, ancho, i, j);
        zonasConectadas++;
      }
    }
  }

  // Mostrar el laberinto ingresado por el usuario
  cout << "Laberinto ingresado:\n";
  for (int i = 0; i < alto; ++i)
  {
    for (int j = 0; j < ancho; ++j)
    {
      cout << laberinto[i][j];
    }
    cout << endl;
  }

  // Mostrar el resultado del análisis
  cout << "Número de zonas transitables independientes: " << zonasConectadas << endl;

  // Liberar la memoria asignada para evitar fugas de memoria
  for (int i = 0; i < alto; ++i)
  {
    delete[] laberinto[i];
    delete[] explorado[i];
  }
  delete[] laberinto;
  delete[] explorado;

  return 0;
}
