#include <iostream>
using namespace std;

int main()
{
  const int LONGITUD_MAXIMA = 1000;
  char *textoOriginal = new char[LONGITUD_MAXIMA + 1];

  cout << "Introduce una frase:\n";
  cin.getline(textoOriginal, LONGITUD_MAXIMA);

  // Crear una nueva cadena para almacenar solo los caracteres alfanuméricos
  char *textoLimpio = new char[LONGITUD_MAXIMA + 1];
  char *ptrOrigen = textoOriginal;
  char *ptrDestino = textoLimpio;

  // Copiar solo los caracteres alfanuméricos
  while (*ptrOrigen)
  {
    if (esCaracterAlfanumerico(*ptrOrigen))
    {
      *ptrDestino++ = *ptrOrigen;
    }
    ++ptrOrigen;
  }
  *ptrDestino = '\0';
  delete[] textoOriginal;

  // Calcular la longitud de la cadena limpia
  int longitud = 0;
  for (char *p = textoLimpio; *p; ++p)
  {
    ++longitud;
  }

  // Invertir la cadena limpia
  char *izquierda = textoLimpio;
  char *derecha = textoLimpio + (longitud - 1);
  while (izquierda < derecha)
  {
    char temporal = *izquierda;
    *izquierda++ = *derecha;
    *derecha-- = temporal;
  }

  // Imprimir la cadena invertida en trozos incrementales
  int posicion = 0;
  for (int tamanoTrozo = 1; posicion < longitud; ++tamanoTrozo)
  {
    int restante = longitud - posicion;
    int tomar = (tamanoTrozo < restante ? tamanoTrozo : restante);
    for (int i = 0; i < tomar; ++i)
    {
      cout << textoLimpio[posicion + i];
    }
    cout << '\n';
    posicion += tomar;
  }

  delete[] textoLimpio;
  return 0;
}
// Función que verifica si un carácter es alfanumérico
bool esCaracterAlfanumerico(char caracter)
{
  return (caracter >= '0' && caracter <= '9') ||
         (caracter >= 'A' && caracter <= 'Z') ||
         (caracter >= 'a' && caracter <= 'z');
}
